cat template.txt > main.cpp
