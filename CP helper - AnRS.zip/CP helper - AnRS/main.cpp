#include <bits/stdc++.h>
using namespace std;

#define int long long
#define all(p) p.begin(), p.end()
#define vsort(p) sort(all(p))
#define rev(p) reverse(all(p))
#define asort(p) sort(p, p + sizeof(p) / sizeof(p[0]))
#define Max(p) *max_element(all(p))
#define Min(p) *min_element(all(p))
#define sp ' '
#define endl '\n'
#define pb push_pack
#define pf push_front
#define pob pop_back
#define pof pop_front
#define eb emplace_back
#define nl() cout << endl
#define vin(p)        \
    for (auto &v : p) \
    cin >> v
#define vout(p)      \
    for (auto v : p) \
    cout << v << sp
#define vc vector
#define st set
const int M = 1e9 + 7;

void soln()
{
    int l, r;
    cin >> l >> r;
    cout << l << sp << r << endl;
}

int32_t main()
{

    int T;
    cin >> T;
    // int T = 1;
    for (int t = 1; t <= T; t++)
    {
        soln();
    }

    return 0;
}
