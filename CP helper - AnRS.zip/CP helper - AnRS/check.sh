g++ main.cpp -o main && ./main < intput.txt > output.txt && bash diff.sh expected_output.txt output.txt
