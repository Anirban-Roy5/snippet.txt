g++ main.cpp -o main && ./main < intput.txt > output.txt
